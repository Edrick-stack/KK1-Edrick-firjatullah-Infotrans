-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Bulan Mei 2021 pada 19.06
-- Versi server: 10.4.10-MariaDB
-- Versi PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kendaraan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_angkot`
--

CREATE TABLE `data_angkot` (
  `id_angkot` varchar(100) NOT NULL,
  `jurusan` varchar(100) NOT NULL,
  `rute` varchar(400) NOT NULL,
  `kota` text NOT NULL,
  `harga` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_angkot`
--

INSERT INTO `data_angkot` (`id_angkot`, `jurusan`, `rute`, `kota`, `harga`) VALUES
('D1/AX ', 'Dukuh Semar – Perumnas', 'Dukuh Semar – Pegambiran – Krucuk – Perumnas', 'Cirebon', 10000),
('D2', 'Dukuh Semar – Krucuk – Majasem', 'Dukuh Semar – Kesambi – Merdeka – Pesisir – Krucuk – Tuparev – Kedawung – Majasem', 'Cirebon', 10500),
('D3', 'Dukuh Semar – Majasem – Kesambi', 'Dukuh Semar – Majasem – Pemuda – Kartini – Pasar Pagi (PGC) – Kesambi', 'Cirebon', 10000),
('D4/BX', 'Dukuh Semar – Pasuketan', 'Dukuh Semar – Kedawung – Tuparev – Hero – Pasuketan', 'Cirebon', 5000),
('D5', 'Dukuh Semar – Perumnas', 'Dukuh Semar – Jagasatru – Pasuketan – PGC – Surya – Krucuk – Stasiun – Grage – Cipto – Terminal – Perumnas', 'Cirebon', 5000),
('D6', 'Dukuh Semar – Perum Rajawali', 'Dukuh Semar – Kesambi – Drajat – Grage – Krucuk – Stasiun – PGC – Karang Getas – Kesambi – Perum Rajawali', 'Cirebon', 15000),
('D7', 'Dukuh Semar – Mas Gandasari – Pilang – Tuparev', 'Dukuh Semar – PGC – Kartini – Wahidin – Pilang – Kedawung – Tuparev – Grage – Pemuda – By Pass – Terminal', 'Cirebon', 7000),
('D8', 'Dukuh Semar – Pilang – Pasar Pagi – Jagasatru', 'Dukuh Semar – Grage – Kedawung – Wahidin – Kartini – PGC – Asia – Pekiringan – Jagasatru – Drajat – Terminal', 'Cirebon', 12000),
('D9', 'Dukuh Semar – Kebun Pelok', 'Dukuh Semar – Kedawung – Evakuasi – Kanggraksan – Kebun Pelok', 'Cirebon', 5000),
('D10', 'Dukuh Semar – Benda', 'Dukuh Semar – Benda', 'Cirebon', 10000),
('GS', 'Gunung Sari – Sumber', 'Gunung Sari – Kanggraksan – kesambi – Cipto – Wahidin – Krucuk – Siliwangi – kesambi – kanggraksan – Sumber', 'Cirebon', 10000),
('GM', 'Gunung Sari – Mundu', 'Gunung Sari – PGC – Kesambi – Cipto – Krucuk – Pesisir – Cangkol – Mundu', 'Cirebon', 7000),
('GP', 'Gunung Sari – Plered', 'Gunung Sari – Kedawung – Tuparev – Wahidin – Pesisir – Bahagia – Tentara Pelajar – Plered', 'Cirebon', 11000),
('GC', 'Gunung Sari – Ciperna', 'Gunung Sari – Merdeka – Grage – Surya – Bahagia – Penggung – Ciperna', 'Cirebon', 9000),
('GG\r\n', 'Gunung Sari – Clancang', 'Gunung Sari – Hero – Klayan – Clancang', 'Cirebon', 8000);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
